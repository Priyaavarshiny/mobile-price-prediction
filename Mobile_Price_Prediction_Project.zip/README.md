
# 📱 Mobile Price Prediction

A machine learning project to predict the price range of mobile phones based on their technical specifications using classification models.

---

## 🧠 Objective

Build a classification model that predicts the price category of a mobile phone using the following labels:

- `0` = Low cost
- `1` = Medium cost
- `2` = High cost
- `3` = Very high cost

This helps understand how features like RAM, battery power, screen resolution, and more affect a phone’s price.

---

## 📂 Files in This Repository

| File Name                   | Description                                |
|----------------------------|--------------------------------------------|
| `mobile_price_predict.ipynb` | Jupyter notebook with complete code        |
| `mobile_price.csv`          | Dataset containing phone features and price range |
| `requirements.txt`          | Python libraries required to run the code  |
| `README.md`                 | Project overview and usage instructions    |

---

## 🛠️ Libraries Used

- Python
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn

---

## ▶️ How to Run

1. Clone or download this repo
2. Install the required libraries using:
   ```bash
   pip install -r requirements.txt
   ```
3. Open the notebook:
   ```
   mobile_price_predict.ipynb
   ```
4. Run all cells to explore the data, train the model, and see the predictions.

---

## 📊 Model Used

- **Random Forest Classifier**
- Accuracy Score: ~**88%** (can vary slightly depending on split)

---

## 📅 Internship Info

- 🔖 **Submitted by:** Priyaavarshiny
- 🧑‍💻 **Internship Project**
- 🗓️ **Month:** April 2025

---

## ✅ Status

- ✔️ Completed
- 📌 Ready for review and submission

---
